package iundemorep.repository.imported.tests;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import iunit.utilities.testcase.execution.TestCaseExecutionHelper;

@RunWith(Suite.class)
@SuiteClasses({ T7_ADD.class, TS5_EMPINF.class, T555_CHKDB21.class })
public class TS1 {

	static String inputXMLFilePath = "testsuites/iundemorep.repository.imported.tests/TS1.xml";

	@BeforeClass
	public static void setUpExecutionEnv() {
		TestCaseExecutionHelper.executeTestSuiteBeforeSteps();
	}

	@AfterClass
	public static void dropExecutionEnv() {
		TestCaseExecutionHelper.executeTestSuiteAfterSteps(inputXMLFilePath);
	}
}